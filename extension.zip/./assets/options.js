import{r as i,j as e,c as a,R as n}from"./global.js";import{c as t}from"./createLucideIcon.js";/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]],c=t("circle-check-big",l);/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]],h=t("info",d);/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],y=t("shield",m);/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]],x=t("trash-2",p);/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],u=t("triangle-alert",g);function f(){const[r,o]=i.useState(!1),s=async()=>{confirm("Are you sure you want to delete all extension data? This cannot be undone.")&&(await chrome.storage.local.clear(),o(!0),setTimeout(()=>o(!1),3e3))};return e.jsxs("div",{style:{padding:"2rem",maxWidth:"800px",margin:"0 auto"},children:[e.jsxs("header",{style:{marginBottom:"2rem",borderBottom:"1px solid #e5e7eb",paddingBottom:"1rem"},children:[e.jsx("h1",{style:{fontSize:"1.5rem",fontWeight:"bold"},children:"Gemini Agent Settings"}),e.jsx("p",{style:{color:"#6b7280"},children:"Manage your preferences and data."})]}),e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"2rem"},children:[e.jsxs("section",{style:{backgroundColor:"white",padding:"1.5rem",borderRadius:"0.5rem",border:"1px solid #e5e7eb"},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"0.75rem",marginBottom:"1rem"},children:[e.jsx(x,{className:"text-red-500",size:24,color:"#ef4444"}),e.jsx("h2",{style:{fontSize:"1.125rem",fontWeight:600},children:"Data Management"})]}),e.jsx("p",{style:{color:"#374151",marginBottom:"1.5rem"},children:"This extension stores chats and macros locally on your device. Clearing data will remove all history and saved automations."}),e.jsxs("button",{onClick:s,style:{padding:"0.5rem 1rem",backgroundColor:"#fee2e2",color:"#dc2626",border:"1px solid #fecaca",borderRadius:"0.375rem",cursor:"pointer",display:"flex",alignItems:"center",gap:"0.5rem",fontWeight:500},children:[r?e.jsx(c,{size:16}):e.jsx(u,{size:16}),r?"Data Cleared":"Clear All Data"]})]}),e.jsxs("section",{style:{backgroundColor:"white",padding:"1.5rem",borderRadius:"0.5rem",border:"1px solid #e5e7eb"},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"0.75rem",marginBottom:"1rem"},children:[e.jsx(y,{className:"text-blue-500",size:24,color:"#3b82f6"}),e.jsx("h2",{style:{fontSize:"1.125rem",fontWeight:600},children:"Privacy & Safety"})]}),e.jsxs("div",{style:{color:"#374151",lineHeight:"1.6"},children:[e.jsxs("p",{style:{marginBottom:"0.5rem"},children:[e.jsx("strong",{children:"Local First:"})," All your data stays on your device. We do not transmit your chats or browsing activity to any external server (except the AI provider you configure)."]}),e.jsxs("p",{children:[e.jsx("strong",{children:"Safe Automation:"})," The agent acts on your behalf but requires confirmation for high-risk actions."]})]})]}),e.jsxs("section",{style:{backgroundColor:"white",padding:"1.5rem",borderRadius:"0.5rem",border:"1px solid #e5e7eb"},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"0.75rem",marginBottom:"1rem"},children:[e.jsx(h,{className:"text-gray-500",size:24,color:"#6b7280"}),e.jsx("h2",{style:{fontSize:"1.125rem",fontWeight:600},children:"About"})]}),e.jsxs("p",{style:{color:"#374151"},children:[e.jsx("strong",{children:"Version:"})," 1.0.0",e.jsx("br",{}),e.jsx("strong",{children:"Built with:"})," React, Vite, TypeScript"]})]})]})]})}a.createRoot(document.getElementById("root")).render(e.jsx(n.StrictMode,{children:e.jsx(f,{})}));
